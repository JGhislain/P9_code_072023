/**
 * @jest-environment jsdom
 */

import { screen } from "@testing-library/dom"
import NewBillUI from "../views/NewBillUI.js"
import NewBill from "../containers/NewBill.js"
import { fireEvent } from "@testing-library/dom";
import mockStore from "../__mocks__/store";
import { ROUTES, ROUTES_PATH } from "../constants/routes";
import {localStorageMock} from "../__mocks__/localStorage.js";
import userEvent from "@testing-library/user-event"
import router from "../app/Router.js";
	
jest.mock("../app/store", () => mockStore)
	
describe("Je suis connecté comme un employé et quand je suis sur la page Nouvelle Note puis quand je soumet une nouvelle Note", () => {
	
	it("La note de frais est sauvegardée", async () => {
	// ---- Affichage du HTML de la page selon la navigation ---------------------------------
	const onNavigate = (pathname) => {
	document.body.innerHTML = ROUTES({ pathname })
	}
//--------------------------------------------------------------------------------------//
//      Utilisation de l'objet 'Object' pour stocker des ensembles de clés/valeurs      //
//--------------------------------------------------------------------------------------//

	// ---- Ici on modifie sur l'objet 'window" la propriété 'localStorage' et on lui attribue la valeur 'localStorageMock' ----
	// ---- correspondant à la fonction simulée du localStorage ------------------------------
	Object.defineProperty(window, "localStorage", { value: localStorageMock })
	
	// ---- Dans le localStorage l'élément 'user' contient le type 'Employee' ----------------
	window.localStorage.setItem("user", JSON.stringify({
	type: "Employee"
	}))

	// ---- Le HTML affiché est celui de la page du formulaire de nouvelle note de frais -----

	const html = NewBillUI()
	document.body.innerHTML = html

	// ---- Création d'un objet NewBill ------------------------------------------------------
	const newBillInit = new NewBill({
	document, onNavigate, store: null, localStorage: window.localStorage
	})

	// ---- Récupération dans le DOM de l'élément formulaire d'une nouvelle note de frais ----
	const formNewBill = screen.getByTestId("form-new-bill")

	// ---- Vérification que l'élément de formulaire d'une nouvelle note de frais est bien trouvé en utilisant toBeTruthy ----
	expect(formNewBill).toBeTruthy()

	// ---- Création d'une fonction simulée avec 'jest.fn' de Jest pour simulée la fonction de gestion de la soumission ----
	// ---- d'une nouvelle note de frais qui est 'handleSubmit' ------------------------------
	const handleSubmit = jest.fn((e) => newBillInit.handleSubmit(e))

	
	// ---- Ajout sur l'élément de formulaire d'un evènement à la soumission déclenchant la fonction 'handleSubmit" ----
	formNewBill.addEventListener("submit", handleSubmit)

	// ---- fireEvent de testingLibrary permet de simuler la soumission du formulaire de nouvelle note de frais ----
	fireEvent.submit(formNewBill)


	// ---- Vérification que la fonction simulée de soumission d"une nouvelle note de frais a bien été appelée ----
	expect(handleSubmit).toHaveBeenCalled()
	});
	
	it("Vérification du fichier note de frais", async() => {


		// ---- Création d'une fonction simulée qui surveille également les appels de la méthode 'bills()' de l'objet mockStore ----
	jest.spyOn(mockStore, "bills")


	// ---- Affichage du HTML de la page selon la navigation ---------------------------------
	const onNavigate = (pathname) => {
	document.body.innerHTML = ROUTES({ pathname })
	} 

//--------------------------------------------------------------------------------------//
//      Utilisation de l'objet 'Object' pour stocker des ensembles de clés/valeurs      //
//--------------------------------------------------------------------------------------//


	// ---- Ici on modifie sur l'objet 'window" la propriété 'localStorage' et on lui attribue la valeur 'localStorageMock' ----
	// ---- correspondant à la fonction simulée du localStorage ------------------------------
	Object.defineProperty(window, "localStorage", { value: localStorageMock })

//--------------------------------------------------------------------------------------//
//      Utilisation de l'objet 'Object' pour stocker des ensembles de clés/valeurs      //
//--------------------------------------------------------------------------------------//

	// ---- Ici on modifie sur l'objet 'window" la propriété 'location' et on lui attribue sur la propriété 'hash' la valeur ----
	// ---- correspondant au chemin pour une nouvelle note de frais --------------------------
	Object.defineProperty(window, "location", { value: { hash: ROUTES_PATH['NewBill']} })

	// ---- Dans le localStorage l'élément 'user' contient le type 'Employee' ----------------
	window.localStorage.setItem("user", JSON.stringify({
	type: "Employee"
	}))	

	// ---- Le HTML affiché est celui de la page du formulaire de nouvelle note de frais -----
	const html = NewBillUI()
	document.body.innerHTML = html

	// ---- Création d'un objet NewBill pour une nouvelle note de frais ----------------------
	const newBillInit = new NewBill({
	document, onNavigate, store: mockStore, localStorage: window.localStorage
	})

	// ---- Création d'un objet File contenant l'array image, s'appelant image.png et étant de type png ----
	const file = new File(['image'], 'image.png', {type: 'image/png'});

	// ---- Création d'une fonction simulée avec 'jest.fn' de Jest pour simulée la fonction de gestion de changement de fichier ----
	// ---- d'une nouvelle note de frais qui est 'handleChangeFile' --------------------------
	const handleChangeFile = jest.fn((e) => newBillInit.handleChangeFile(e))

	// ---- Récupération de l'élément du formulaire de nouvelle note de frais dans le DOM ----
	const formNewBill = screen.getByTestId("form-new-bill")

	// ---- Récupération dans le DOM de l'élément <input> de type file permettant de sélectionner un fichier ----
	const billFile = screen.getByTestId('file')

	// ---- Ajout d'un évènement sur le <input> de type file lors d'un changement de fichier avec appel de la fonction ----
	// ---- 'handleChangeFile' ---------------------------------------------------------------
	billFile.addEventListener("change", handleChangeFile);

	// ---- userEvent de testingLibrary permet de simuler le téléchargement de fichiers par un utilisateur, ici le fichier 'file' ----
	// ---- est chargé dans le <input> 'billFile' --------------------------------------------
	userEvent.upload(billFile, file)
	
	// ---- Vérification que le <input> a bien un fichier qui a été téléchargé, vérification que le fichier est bien défini ----
	expect(billFile.files[0].name).toBeDefined()

	// ---- Vérification que la fonction simulée 'handleChangeFile' a bien été appelée -------
	expect(handleChangeFile).toBeCalled()

	// ---- Création d'une fonction simulée avec 'jest.fn' de Jest pour simulée la fonction de gestion de la soumission du ----
	// ---- formulaire d'une nouvelle note de frais qui est 'handleSubmit' -------------------
	const handleSubmit = jest.fn((e) => newBillInit.handleSubmit(e))

	// ---- Ajout d'un évènement à la soumission sur le formulaire de nouvelle note de frais avec appel de la fonction ----
	// ---- 'handleSubmit' -------------------------------------------------------------------
	formNewBill.addEventListener("submit", handleSubmit)

	// ---- fireEvent de testingLibrary permet de simuler la soumission du formulaire de nouvelle note de frais ----
	fireEvent.submit(formNewBill)

	// ---- Vérification que la fonction simulée 'handleSubmit' a bien été appelée -----------
	expect(handleSubmit).toHaveBeenCalled()
	})
	
//--------------------------------------------------------------------------------------//
//                                Les erreurs 404 et 500                                //
//--------------------------------------------------------------------------------------//

	describe("Quand une erreur se produit sur l'API", () => {

		// ---- Utilisation de beforeEeach de Jest, pour exécuter un morceau de code pour chaque 'it' du bloc 'describe' ----
		beforeEach(() => {
		jest.spyOn(mockStore, "bills")
		Object.defineProperty(window, "localStorage", {
		value: localStorageMock,
		})
		window.localStorage.setItem(
			"user",
			JSON.stringify({
			type: "Employee",
			email: "a@a",
		})
		)
		const root = document.createElement("div")
		root.setAttribute("id", "root")
		document.body.appendChild(root)
		router()
	})
	
	it("Récupération des notes de frais de l'API et indication de l'échec avec un message d'erreur 404", async () => {
	mockStore.bills.mockImplementationOnce(() => {
	return {
	list: () => {
	return Promise.reject(new Error("Erreur 404"))
	},
	}
	})

	// ---- Le HTML affiché est celui de la page des notes de frais --------------------------
	window.onNavigate(ROUTES_PATH["Bills"])

	// ---- On attend la réponse de la promesse ----------------------------------------------
	await new Promise(process.nextTick)

	// ---- Récupération dans le DOM de la page de l'élément contenant 'Erreur 404' avec le screen de Testing library ----
	const message = await screen.getByText(/Erreur 404/)

	// ---- Vérification que le message d'erreur 'Erreur 404' est bien affiché sur la page (dans le DOM) avec toBeTruthy ----
	expect(message).toBeTruthy()
	});
	
	it("Récupération des notes de frais de l'API et indication de l'échec avec un message d'erreur 500", async () => {
	mockStore.bills.mockImplementationOnce(() => {
	return {
	list: () => {
	return Promise.reject(new Error("Erreur 500"))
	},
	}
	})
	window.onNavigate(ROUTES_PATH["Bills"])
	await new Promise(process.nextTick)
	const message = await screen.getByText(/Erreur 500/)
	expect(message).toBeTruthy()
	})
	})
})

// --------------------------------------------------------------------------------------//
//            Test de la réponse de l'API lors de la mise à jour d'une note              //
// --------------------------------------------------------------------------------------//

// ---- Mise en place de la simulation de la méthode 'update' du 'mockStore' ------------
jest.spyOn(mockStore, "bills").mockImplementation(() => {
	return {
	  update: jest.fn().mockResolvedValue({ status: 201 })
	}
  });
  
  // ---- Test unitaire pour vérifier que l'API retourne une réponse sans erreur -----------
  it("Vérifie que l'API retourne une réponse sans erreur", async () => {
	
	// ---- Initialisation du test ---------------------------------------------------------
	// ---- Configuration de la fonction de navigation pour afficher le bon HTML -----------
	const onNavigate = (pathname) => {
	  document.body.innerHTML = ROUTES({ pathname });
	}
	
	// ---- Configuration du localStorage pour simuler un utilisateur connecté --------------
	Object.defineProperty(window, "localStorage", { value: localStorageMock });
	window.localStorage.setItem("user", JSON.stringify({
	  type: "Employee"
	}));
	
	// ---- Création d'un nouvel objet NewBill ----------------------------------------------
	const newBillInit = new NewBill({
	  document, onNavigate, store: mockStore, localStorage: window.localStorage
	});
	
	// ---- Exécution du code à tester -----------------------------------------------------
	// ---- Récupération du formulaire de nouvelle note de frais dans le DOM ---------------
	const formNewBill = screen.getByTestId("form-new-bill");
	
	// ---- Création d'une fonction simulée pour la soumission du formulaire ---------------
	const handleSubmit = jest.fn((e) => newBillInit.handleSubmit(e));
	
	// ---- Ajout d'un écouteur d'événement pour la soumission du formulaire ---------------
	formNewBill.addEventListener("submit", handleSubmit);
	
	// ---- Simulation de la soumission du formulaire --------------------------------------
	fireEvent.submit(formNewBill);
	
	// ---- Vérification des attentes ------------------------------------------------------
	
	// ---- Vérification que la méthode 'update' a été appelée avec un statut de 201 --------
	expect(mockStore.bills().update).toHaveBeenCalledWith(expect.objectContaining({
	  status: 201
	}));
  });
  